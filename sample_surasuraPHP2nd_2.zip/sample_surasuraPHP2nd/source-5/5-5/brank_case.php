<?php
  $i = 0;
  switch ($i){
    case 0:
    case 1:
      echo "iは0か1です<br>";
      break;
    case 2:
      echo "iは2です<br>";
      break;
  }
?>
