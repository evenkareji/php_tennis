<?php
  $i = 0;
  switch ($i){
    case 0:
      echo "iは0に等しい<br>";
    case 1:
      echo "iは1に等しい<br>";
  }
?>
