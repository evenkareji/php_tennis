<?php
  $friends = array("はるき", "かおる", "ひでと");
  for ($i = 0; $i < 3; $i++){	// $iが0から3未満（0〜2）のループ
    echo $friends[$i]."<br>";	// $friendsの指定要素を表示
  }
?>
