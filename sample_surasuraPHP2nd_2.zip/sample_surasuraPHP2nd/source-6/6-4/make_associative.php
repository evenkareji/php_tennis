<pre>
<?php
  // array関数で連想配列を作成する
  $result1 = array(
    "Japanese" => 80,
    "math" => 75,
    "science" => 90
  );
  var_dump($result1);
  // []で配列を作成する
  $result2 = [
    "history" => 85,
    "English" => 80
  ];
  var_dump($result2);
?>
</pre>

