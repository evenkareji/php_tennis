<pre>
<?php
  $class1 = array("はるき", "かおる", "ひでと");
  $class2 = array("ゆきこ", "ゆか", "まなみ");
  $students = array($class1, $class2);
  var_dump($class1);
  var_dump($class2);
  var_dump($students);
?>
