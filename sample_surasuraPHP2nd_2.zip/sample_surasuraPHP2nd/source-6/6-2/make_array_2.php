<pre>
<?php
  // []で配列を作成する
  $friends = ["はるき", "かおる", "ひでと"];
  var_dump($friends); // 配列の中身を確認
?>
</pre>
