<pre>
<?php
  var_dump(PHP_INT_MAX);	// 整数型の最大値
  var_dump(PHP_INT_MAX+1);	// 整数型の最大値+1
?>
