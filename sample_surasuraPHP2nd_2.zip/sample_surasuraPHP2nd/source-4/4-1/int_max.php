<?php echo PHP_INT_MAX; ?>
