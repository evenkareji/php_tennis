<?php
  $name = "山田";	// $nameに「山田」を代入
  $name .= "花子";	// $name = $name . "花子" と同じ意味
  echo "ようこそ" . $name . "さん";	// 表示
?>
