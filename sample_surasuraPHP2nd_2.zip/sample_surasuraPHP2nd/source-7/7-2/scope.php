<?php
  function print_name(){
    $name = "太郎";
    echo "僕の名前は".$name."です。<br>";
  }
  print_name();
  echo $name;
?>
