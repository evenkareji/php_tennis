<?php
  foreach ($_GET as $key => $value){
    echo 'キー：' . $key . '<br>';
    echo '値：' . $value . '<br><br>';
  }
?>
