<?php
  $page = $_GET['page'];
  echo 'リクエストされたページは' . $page . 'です。';
?>
